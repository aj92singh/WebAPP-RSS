export class RSSFeed{
    id :number;
    FeedUrl: string;
    Name:string;
}